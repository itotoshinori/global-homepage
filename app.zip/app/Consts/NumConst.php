<?php

namespace App\Consts;

class NumConst
{
    const LIST = [
        '1' => ['num' => '2201', 'file' => '1tntVC5s7HosdfBeEPdo04ZOq4LKDMm7yN49HcLt.png'],
        '2' => ['num' => '5436', 'file' => 'GB1VQqOg1rrFRYxeGYc4UiwCWFvRjd7PXCx5kBHQ.png'],
        '3' => ['num' => '8342', 'file' => 'Qi674bEyfxG5jQeyVtIIwEEyNDgH2XMDUmonJAIb.png'],
    ];
}
